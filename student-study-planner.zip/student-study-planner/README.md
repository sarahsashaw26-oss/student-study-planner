# StudyMate — Student Study Planner

StudyMate is a beginner-friendly, responsive study planner built with HTML, CSS, and vanilla JavaScript. It helps students organize assignments, record due dates, set priorities, and track completed work.

## Features

- Add tasks with a subject, due date, and priority.
- Mark tasks as completed or pending.
- Filter tasks by status.
- Delete tasks when they are no longer needed.
- View total, pending, and completed task counts.
- Save tasks in the browser with `localStorage`.
- Responsive layout for phones, tablets, and laptops.

## Technologies used

- HTML5 for page structure
- CSS3 for styling and responsive layouts
- JavaScript for task management and interactivity
- Browser local storage for saving tasks

## How to run the project

1. Download or clone this repository.
2. Open `index.html` in a web browser.
3. Add a task using the form.

No installation or build tools are required.

## Project structure

```text
student-study-planner/
├── index.html
├── style.css
├── script.js
└── README.md
```

## What I learned

This project gives me practice with semantic HTML, CSS Grid and Flexbox, media queries, DOM manipulation, form validation, event listeners, and local storage. It also demonstrates how to make a web interface usable on both mobile and desktop screens.

## Future improvements

- Add task editing.
- Add search and sorting by due date.
- Add reminders and a calendar view.
- Add user accounts and a database in a future version.

## Author

Student project for Web and Mobile Applications Development.
