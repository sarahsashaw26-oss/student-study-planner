const taskForm = document.querySelector('#task-form');
const taskList = document.querySelector('#task-list');
const emptyMessage = document.querySelector('#empty-message');
const taskFilter = document.querySelector('#task-filter');

let tasks = loadTasks();

function loadTasks() {
  try {
    return JSON.parse(localStorage.getItem('studymate-tasks')) || [];
  } catch (error) {
    return [];
  }
}

function saveTasks() {
  localStorage.setItem('studymate-tasks', JSON.stringify(tasks));
}

function showToday() {
  const today = new Date();
  document.querySelector('#today-date').textContent = today.toLocaleDateString(undefined, {
    weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
  });
}

function updateStats() {
  const completed = tasks.filter(task => task.completed).length;
  document.querySelector('#total-count').textContent = tasks.length;
  document.querySelector('#pending-count').textContent = tasks.length - completed;
  document.querySelector('#completed-count').textContent = completed;
}

function renderTasks() {
  taskList.replaceChildren();
  const filter = taskFilter.value;
  const visibleTasks = tasks.filter(task => {
    if (filter === 'pending') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  emptyMessage.hidden = visibleTasks.length > 0;
  emptyMessage.textContent = tasks.length === 0
    ? 'No tasks yet. Add your first task above.'
    : 'No tasks match this filter.';

  visibleTasks.forEach(task => {
    const item = document.createElement('article');
    item.className = `task-item${task.completed ? ' is-complete' : ''}`;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'task-check';
    checkbox.checked = task.completed;
    checkbox.setAttribute('aria-label', `Mark ${task.title} as complete`);
    checkbox.addEventListener('change', () => {
      task.completed = checkbox.checked;
      saveTasks();
      renderTasks();
    });

    const content = document.createElement('div');
    content.className = 'task-content';

    const title = document.createElement('p');
    title.className = 'task-title';
    title.textContent = task.title;

    const meta = document.createElement('p');
    meta.className = 'task-meta';
    meta.textContent = `${task.subject} · Due ${formatDate(task.dueDate)}`;

    content.append(title, meta);

    const priority = document.createElement('span');
    priority.className = `priority ${task.priority}`;
    priority.textContent = task.priority;

    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-button';
    deleteButton.type = 'button';
    deleteButton.textContent = 'Delete';
    deleteButton.setAttribute('aria-label', `Delete ${task.title}`);
    deleteButton.addEventListener('click', () => {
      tasks = tasks.filter(item => item.id !== task.id);
      saveTasks();
      renderTasks();
    });

    item.append(checkbox, content, priority, deleteButton);
    taskList.append(item);
  });

  updateStats();
}

function formatDate(dateString) {
  if (!dateString) return 'not set';
  const date = new Date(`${dateString}T00:00:00`);
  return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

taskForm.addEventListener('submit', event => {
  event.preventDefault();

  const title = document.querySelector('#task-title').value.trim();
  const subject = document.querySelector('#task-subject').value.trim();
  const dueDate = document.querySelector('#task-date').value;
  const priority = document.querySelector('#task-priority').value;

  if (!title || !subject || !dueDate) return;

  tasks.unshift({
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    title,
    subject,
    dueDate,
    priority,
    completed: false
  });

  saveTasks();
  taskForm.reset();
  document.querySelector('#task-priority').value = 'Medium';
  taskFilter.value = 'all';
  renderTasks();
});

taskFilter.addEventListener('change', renderTasks);

showToday();
renderTasks();
